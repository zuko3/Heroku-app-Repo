https://teropa.info/blog/2015/03/02/change-and-its-detection-in-javascript-frameworks.html

ES6 Documents
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

1) Setting Up a Babel Project
	npm init
	npm install babel-cli babel-core --save-dev
	npm install babel-preset-es2015 --save-dev
	npm install http-server --save-dev
	
	Open package.json in your favorite code editor.

	"scripts": {
		"babel": "babel --presets es2015 js/main.js -o build/main.bundle.js",
		"start": "http-server"
	},

	
2)Set Build and Run Babel
	 npm run babel
	 
3)Open index.html in your code editor, and modify the <script> tag as follows to load build/main.bundle.js, the compiled version of js/main.js:
	<script src="build/main.bundle.js"></script>
	
	npm start
	
	
4)If port 8080 is already in use on your computer, modify the start script in package.json and specify a port that is available on your computer. For example:

	"scripts": {
		"babel": "babel --presets es2015 js/main.js -o build/main.bundle.js",
		"start": "http-server -p 9000"
	},

	
	
	
5)Using let Variables
+++++++++++++++++++++++++++++++++++++++++++++++++++++++

ECMAScript 6 introduces a new keyword to declare variables: let. Unlike variables declared with var that are function-scoped, variables declared with let are block-scoped: they only exist in the block they are defined in.



var calculateMonthlyPayment = function(principal, years, rate) {
    if (rate) {
        var monthlyRate = rate / 100 / 12;
    }
    var monthlyPayment = principal * monthlyRate / 
                         (1 - (Math.pow(1/(1 + monthlyRate), years * 12)));
    return monthlyPayment;
};


Notice that on line 5, the monthlyRate variable is available even though it was declared within the if block. This is because variables declared with var are function-scoped, and not block-scoped. 


If Replace all the occurrences of var with let we will get error as, because unlike var variables which are function-scoped, let variables are block-scoped: they only exist in the block they are defined in.




let calculateMonthlyPayment = function(principal, years, rate) {
    let monthlyRate = 0;
    if (rate) {
        monthlyRate = rate / 100 / 12;
    }
    let monthlyPayment = principal * monthlyRate / 
                         (1 - (Math.pow(1/(1 + monthlyRate), years * 12)));
    return monthlyPayment;
};



npm run babel



6) Using Destructuring
++++++++++++++++++++++++++++++++++++++++++++++++++

ECMAScript 6 introduces new syntax that makes it easy to create objects based on variables. Also we can  create variables based on objects and arrays.


Step 1: Creating Objects from Variables
		return {principal, years, rate, monthlyPayment, monthlyRate};
		
		
		This is a shorthand for the following ECMAScript 5 syntax:
		return { principal: principal, 
				 years: years, 
				 rate: rate, 
				 monthlyPayment: monthlyPayment, 
				 monthlyRate: monthlyRate };
				 
				 
				 
Step 2: Creating Variables from an Object using Destructuring.

		let {monthlyPayment, monthlyRate} = calculateMonthlyPayment(principal, years, rate);
		
				
		This is a shorthand for the following ECMAScript 5 code:
		
			var mortgage = calculateMonthlyPayment(principal, years, rate);
			var monthlyPayment = mortgage.monthlyPayment;
			var monthlyRate = mortgage.monthlyRate;
			
			
document.getElementById("monthlyRate").innerHTML = (monthlyRate * 100).toFixed(2);



7) Using Arrow Functions
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
The ECMAScript 6 arrow function syntax is a shorthand for the ECMAScript 5 function syntax. It supports both block and expression bodies.
The value of this inside the arrow function is not altered: it is the same as the value of this outside the function. No more var self = this to keep track of the current scope.


let calculateAmortization = (principal, years, rate) => {
    let {monthlyRate, monthlyPayment} = calculateMonthlyPayment(principal, years, rate);
    let balance = principal;
    let amortization = [];
    for (let y=0; y<years; y++) {
        let interestY = 0;  //Interest payment for year y
        let principalY = 0; //Principal payment for year y
        for (let m=0; m<12; m++) {
            let interestM = balance * monthlyRate;       //Interest payment for month m
            let principalM = monthlyPayment - interestM; //Principal payment for month m
            interestY = interestY + interestM;
            principalY = principalY + principalM;
            balance = balance - principalM;
        }
        amortization.push({principalY, interestY, balance});
    }
    return {monthlyPayment, monthlyRate, amortization};
};




document.getElementById('calcBtn').addEventListener('click', () => {
    let principal = document.getElementById("principal").value;
    let years = document.getElementById("years").value;
    let rate = document.getElementById("rate").value;
    let {monthlyPayment, monthlyRate, amortization} = calculateAmortization(principal, years, rate);
    document.getElementById("monthlyPayment").innerHTML = monthlyPayment.toFixed(2);
    document.getElementById("monthlyRate").innerHTML = (monthlyRate * 100).toFixed(2);
    
	//Here amortization is the array of the object
	amortization.forEach(month => console.log(month));
});


Note on this and arrow function.
-------------------------------------
ES5 version:
var obj5 = {
  greet: "Hi, Welcome ",
  greetUser : function(user) {
        setTimeout(function(){
			console.log(this.greet + ": " +  user); // "this" here is undefined.
        });
     }
};
obj5.greetUser("Katty"); //undefined: Katty
The callback passed to setTimeout is an ES5 function and it has it's own this which is undefined, hence we get output: undefined: Katty 


ES6 version:
var obj6 = {
  greet: "Hi, Welcome ",
  greetUser : function(user) {
    setTimeout(() => console.log(this.greet + ": " +  user)); 
      // this here refers to outer context
   }
};
obj6.greetUser("Katty"); //Hi, Welcome: Katty

The callback passed to setTimeout is an ES6 arrow function and it does NOT have it's own this so it takes it from it's outer context,hence we get output Hi, Welcome: Katty. 


To solve This in es5 we use:
var obj5 = {
  greet: "Hi, Welcome ",
  greetUser : function(user) {
		self=this;
        setTimeout(function(){
			console.log(self.greet + ": " +  user); 
        });
     }
};
obj5.greetUser("Katty"); //Hi, Welcome: Katty



8) WEBPACK
+++++++++++++++++++++++++++++++++++++++++
webpack is a module bundler for modern JavaScript applications. When webpack processes your application, it  builds a dependency graph that includes every module your application needs, then packages all of those modules into a small number of bundles - often only one - to be loaded by the browser.

It has Four Core Concepts: entry, output, loaders, and plugins.


a)Entry:
	The entry point tells webpack where to start.
	You can think of your application's entry point  or the first file to kick off your app.

	const config = {
			entry: './path/to/my/entry/file.js'
	};
	module.exports = config;
	
	
	
	const config = {
		  entry: {
				app: './src/app.js',
				vendors: './src/vendors.js'
			}
	};
	module.exports = config;
	
	
b)Output:
	You need to tell webpack where to bundle your application.
	
	
	const config = {
		  output: {
			filename: 'bundle.js',
			path: '/home/proj/public/assets'
		  }
	};
	module.exports = config;
		
	
	
	
	const config = {
	  entry: './src/app.js',
	  output: {
			filename: 'bundle.js',
			path: __dirname + '/build'
		  }
	};
	module.exports = config;
	// writes to disk: ./build/bundle.js
	
	
	
	const config ={
		 entry: {
			app: './src/app.js',
			search: './src/search.js'
		 },
		 output: {
			filename: '[name].js',
			path: __dirname + '/build'
		 }
	};
	module.exports = config;
	// writes to disk: ./build/app.js, ./build/search.js
	

c)Loaders:
	Loaders allow you to preprocess files as you “load” them.
	Loaders can transform files from a different language like, CoffeeScript to JavaScript

d) Plugins:
	While Loaders allow you to preprocess files as you “load” them. Loaders can transform files from a different language like, CoffeeScript to JavaScript. plugins can be used to perform a wider range of tasks. Plugins range from bundle optimization and minification.

const config = {
	  entry: {},
	  output: {},
	  module: {},
	  plugins: [
		new webpack.optimize.UglifyJsPlugin()
	  ]
};
module.exports = config;

	
9)Setting Up Webpack
+++++++++++++++++++++++++++++++++++++++++++++++++++++++
a)install the babel-loader and webpack modules:

	npm install babel-loader webpack --save-dev


	
b)Open package.json in your code editor, and add a webpack script:

	"scripts": {
		"babel": "babel --presets es2015 js/main.js -o build/main.bundle.js",
		"start": "http-server",
		"webpack": "webpack"
	}

	
	
c)create a new file named webpack.config.js:

	var path = require('path');
	var webpack = require('webpack');

	module.exports = {
		 entry: {
			app: './src/app.js',
			search: './src/search.js'
		 },
		 output: {
			 path: path.resolve(__dirname, 'build'),
			 filename: '[name].js'
		 },
		 module: {
			 loaders: [
				 {
					 test: /\.js$/,
					 loader: 'babel-loader',
					 query: {
						 presets: ['es2015']
					 }
				 }
			 ]
		 }
	};
	
	
	npm run webpack
	
	

10)Using Modules
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
JavaScript modules are just a way of packaging related JavaScript code  which can be consumed by other JavaScript programs.


The import statement is used to import functions, objects or primitives that have been exported from an external module.

The export statement is used to export functions, objects or primitives from a given module



1)Create a new file named mortgage.js in the js directory.

2)Copy the calculateMonthlyPayment and calculateAmortization functions from main.js into mortgage.js.

3)Add the export keyword in front of both functions to make them available as part of the module public API. mortgage.js should now look like this:


step 1:

	export let calculateMonthlyPayment = (principal, years, rate) => {
		let monthlyRate = 0;
		if (rate) {
			monthlyRate = rate / 100 / 12;
		}
		let monthlyPayment = principal * monthlyRate / (1 - (Math.pow(1/(1 + monthlyRate),
				years * 12)));
		return {principal, years, rate, monthlyPayment, monthlyRate};
	};
		
	export let calculateAmortization = (principal, years, rate) => {
		let {monthlyRate, monthlyPayment} = calculateMonthlyPayment(principal, years, rate);
		let balance = principal;
		let amortization = [];
		for (let y=0; y<years; y++) {
			let interestY = 0;  //Interest payment for year y
			let principalY = 0; //Principal payment for year y
			for (let m=0; m<12; m++) {
				let interestM = balance * monthlyRate;       //Interest payment for month m
				let principalM = monthlyPayment - interestM; //Principal payment for month m
				interestY = interestY + interestM;
				principalY = principalY + principalM;
				balance = balance - principalM;
			}
			amortization.push({principalY, interestY, balance});
		}
		return {monthlyPayment, monthlyRate, amortization};
	};
	
	
step 2: Use the Module

	import * as mortgage from './mortgage';
	let {monthlyPayment, monthlyRate, amortization} = mortgage.calculateAmortization(principal, years, rate);
	
	
	npm run webpack
	
	
	
	
11)Using Classes
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ECMAScript 6 introduces the concept of class. In ECMAScript 6, the class syntax is syntactical sugar on top of the existing prototype-based inheritance model


class Mortgage {
    
    constructor(principal, years, rate) {
        this.principal = principal;
        this.years = years;
        this.rate = rate;
    }
    
    get monthlyPayment() {
        let monthlyRate = this.rate / 100 / 12;
        return this.principal * monthlyRate / (1 - (Math.pow(1/(1 + monthlyRate),
                    this.years * 12)));
    }
    
    get amortization() {
        let monthlyPayment = this.monthlyPayment;
        let monthlyRate = this.rate / 100 / 12;
        let balance = this.principal;
        let amortization = [];
        for (let y=0; y<this.years; y++) {
            let interestY = 0;
            let principalY = 0;
            for (let m=0; m<12; m++) {
                let interestM = balance * monthlyRate;
                let principalM = monthlyPayment - interestM;
                interestY = interestY + interestM;
                principalY = principalY + principalM;
                balance = balance - principalM;
            }
            amortization.push({principalY, interestY, balance});
        }
        return amortization;
    }
    
}




document.getElementById('calcBtn').addEventListener('click', () => {
		let principal = document.getElementById("principal").value;
		let years = document.getElementById("years").value;
		let rate = document.getElementById("rate").value;
		let mortgage = new Mortgage(principal, years, rate);
		document.getElementById("monthlyPayment").innerHTML = mortgage.monthlyPayment.toFixed(2);
		document.getElementById("monthlyRate").innerHTML = (rate / 12).toFixed(2);
		mortgage.amortization.forEach(function(year, index){
			console.log('year'+'index');
		});
	});
	
	
Using Classes in Modules:

	Add the export default keywords in front of the class definition.
	
	
	
	export default class Mortgage {
    
		constructor(principal, years, rate) {
			this.principal = principal;
			this.years = years;
			this.rate = rate;
		}
		
		get monthlyPayment() {
			let monthlyRate = this.rate / 100 / 12;
			return this.principal * monthlyRate / (1 - (Math.pow(1/(1 + monthlyRate),
					this.years * 12)));
		}
		
		get amortization() {
			let monthlyPayment = this.monthlyPayment;
			let monthlyRate = this.rate / 100 / 12;
			let balance = this.principal;
			let amortization = [];
			for (let y=0; y<this.years; y++) {
				let interestY = 0;
				let principalY = 0;
				for (let m=0; m<12; m++) {
					let interestM = balance * monthlyRate;
					let principalM = monthlyPayment - interestM;
					interestY = interestY + interestM;
					principalY = principalY + principalM;
					balance = balance - principalM;
				}
				amortization.push({principalY, interestY, balance});
			}
			return amortization;
		}
    
    }
	
	
	
12) Export vs Export Default:
++++++++++++++++++++++++++++++++

	// Three different export styles
	export foo;
	export default foo;
	export = foo;

	// The three matching import styles
	import {foo} from 'blah';
	import foo from 'blah';
	import * as foo from 'blah';
	


	
13)Using Promises
++++++++++++++++++++++++++++++++++++
Promises have replaced callback functions as the way for handling asynchronous calls.


without promise async call :
---------------------------------------
	let url = "rates.json";
    
	fetch(url)
	.then(response => response.json())
	.then(rates => {
		  let html = '';
		  rates.forEach(rate => html +='<tr><td>${rate.name}</td><td>${rate.years}</td><td>${rate.rate}%</td></tr>');
		  document.getElementById("rates").innerHTML = html;
	})
	.catch(e => console.log(e));
	
	
	
	or 
	
	
	fetch(url)
	.then(function(response){
		return response.json()
	})
	.then(function(rates){
		  let html = '';
		  rates.forEach(function(rate){
			  html +='<tr><td>${rate.name}</td><td>${rate.years}</td><td>${rate.rate}%</td></tr>'
		  });
		  document.getElementById("rates").innerHTML = html;
	})
	.catch(function(e){
		console.log(e);
	});
	
	
	
	or 
	
	//Post Implemention using the fetch
	
	postData('http://example.com/answer', {answer: 42})
	.then(data => console.log(data)) // JSON from `response.json()` call
	.catch(error => console.error(error))

	function postData(url, data) {
		  return fetch(url, {
			body: JSON.stringify(data),
			cache: 'no-cache',
			credentials: 'same-origin',
			headers: {
			  'user-agent': 'Mozilla/4.0 MDN Example',
			  'content-type': 'application/json'
			},
			method: 'POST',
			mode: 'cors',
		  })
		  .then(response => response.json());
	}
	
	
with promise async call :
----------------------------------------	
i)	
	let rates = [{"name": "30 years fixed","rate": "13","years": "30"},{"name": "20 years fixed","rate": "2.8","years": "20"}];
	
	export let findAll = function(){
		return new Promise(function(resolve, reject){
			if (rates){
				resolve(rates);
			} else {
				reject("No rates");
			}
		});
	}
	
	
	import * as service from './rate-service-mock';
	
	
	service.findAll()
	.then(function(rates){
		  let html = '';
		  rates.forEach(function(rate){
			  html +='<tr><td>${rate.name}</td><td>${rate.years}</td><td>${rate.rate}%</td></tr>'
		  });
		  document.getElementById("rates").innerHTML = html;
	})
	.catch(function(e){
		console.log(e);
	});
	
	
	npm run webpack
	
ii)	

	let rates = [{"name": "30 years fixed","rate": "13","years": "30"},{"name": "20 years fixed","rate": "2.8","years": "20"}];
	
	let findAll = function(){
		return new Promise(function(resolve, reject){
			if (rates){
				resolve(rates);
			} else {
				reject("No rates");
			}
		});
	}
		
	findAll().then(function(rates){
		  let html = '';
		  rates.forEach(function(rate){
			 console.log(rate);
		  });
		 
	}).catch(function(e){
		console.log(e);
	});

	

iii)

	var  getSum=function(n1, n2) {   
		  var isAnyNegative = function() {
			  return n1 < 0 || n2 < 0;
		  }   
		  var promise = new Promise(function(resolve, reject) {
			  if (isAnyNegative()){
				  reject(Error("Negatives not supported"))
				 } 
				 resolve(n1 + n2);   
		  });   
		  return promise;   
	}  


	getSum(5, 6)   
   .then(function(result){   
      console.log(result);    
   }).catch(function(e){
		console.log(e);
	});
   console.log("End of script ");
   
 iv)
	 function get(url) {
	  var promise =  new Promise(function(resolve, reject) {
		var req = new XMLHttpRequest();
		req.open('GET', url);
		req.onload = function() {
		  if (req.status == 200) {
			resolve(req.response);
		  }
		  else {
			reject(new Error(req.statusText));
		  }
		};
		req.onerror = function() {
		  reject(new Error("Network Error"));
		};
		req.send();
	  });
	  return promise;
	}
   
   
   
   
 15)Understanding Callback
 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 A function may be passed as a parameter to another function. This mechanism is termed as a Callback
 
 synchronous call
 =======================

   function notifyAll(fnSms, fnEmail) {   
      console.log('starting notification process');   
      fnSms();   
      fnEmail();   
   }   
   notifyAll(function() {   
      console.log("Sms send ..");   
   }, 
   function() {   
      console.log("email send ..");   
   });   
   console.log("End of script"); 
   //executes last or blocked by other methods  
   
   
In the code mentioned above, the function calls are synchronous. It means the UI thread would be waiting to complete the entire notification process. Synchronous calls become blocking calls.



asynchronous call
===========================

	function notifyAll(fnSms, fnEmail) {   
      setTimeout(function() {   
         console.log('starting notification process');   
         fnSms();   
         fnEmail();   
      }, 2000);   
	}  
	
	notifyAll(function() {   
      console.log("Sms send ..");   
	},  
	function() {   
      console.log("email send ..");   
	});   
    console.log("End of script"); //executes first or not blocked by others 
	
	
In this case, the notification process has been wrapped with timeout. Hence, it will take a two seconds delay, set by the code. The notifyAll() will be invoked and the main thread goes ahead like executing other methods. Hence, the notification process will not block the main JavaScript thread.




In case of multiple callbacks, the code will look scary.

<script>   
   setTimeout(function() {   
      console.log("one");   
      setTimeout(function() {   
         console.log("two");   
         setTimeout(function() {   
            console.log("three");   
         }, 1000);   
      }, 1000);   
   }, 1000);   
</script>

ES6 comes to your rescue by introducing the concept of promises.
Promises help you execute the multiple async operations together in a much cleaner code style.


var  f1=function(n1, n2) {   		 
		  var promise = new Promise(function(resolve, reject) {
			   setTimeout(function() {
				   resolve();
			   },1000);  
		  });   
		  return promise;   
}

var  f2=function(n1, n2) {   		 
		  var promise = new Promise(function(resolve, reject) {
			   setTimeout(function() {
				   resolve();
			   },1000);  
		  });   
		  return promise;   
}

var  f3=function(n1, n2) {   		 
		  var promise = new Promise(function(resolve, reject) {
			   setTimeout(function() {
				   resolve();
			   },1000);  
		  });   
		  return promise;   
}


f1().then(function(){
	console.log('one');
	f2().then(function(){
		console.log('two');
		f3().then(function(){
			console.log('three');
		});
	});
});



CALL BACK ADVANCED: IMPORTANT.
---------------------------------
i)

<!DOCTYPE html>
<html>

<body>
  <script>
    /*the program demostarte the use of the callback*/
	'use strict'
	function loadScript(url,handleCallBack){
		let script=document.createElement('script');
		script.src=url;
		script.onload=function(){
			handleCallBack(null,script)
		}
		script.onerror=function(){
			handleCallBack(new Error("unable to load"),script)
		}
		window.document.head.append(script)
	}
	
	loadScript('http://javascript.info/callbacks',function(error,script){
		if(error){
			alert(`error url ${script.src} cant be loaded !`);
		}else{
			alert(`success url ${script.src} has been loaded !`);
		}
		
	});
  </script>
</body>

</html>


ii) 
We can try to alleviate the problem by making every action a standalone function, like this:

loadScript('1.js', step1);

function step1(error, script) {
  if (error) {
    handleError(error);
  } else {
    // ...
    loadScript('2.js', step2);
  }
}

function step2(error, script) {
  if (error) {
    handleError(error);
  } else {
    // ...
    loadScript('3.js', step3);
  }
}

function step3(error, script) {
  if (error) {
    handleError(error);
  } else {
    // ...continue after all scripts are loaded (*)
  }
};



Example: loadScript
+++++++++++++++++++++++++++++++++
Here’s the callback-based variant, just to remind it:

function loadScript(src, callback) {
  let script = document.createElement('script');
  script.src = src;

  script.onload = () => callback(null, script);
  script.onerror = () => callback(new Error(`Script load error ` + src));

  document.head.append(script);
}




Let’s rewrite it using promises.

function loadScript(src) {
  return new Promise(function(resolve, reject) {
    let script = document.createElement('script');
    script.src = src;

    script.onload = () => resolve(script);
    script.onerror = () => reject(new Error("Script load error: " + src));

    document.head.append(script);
  });
}


let promise = loadScript("https://cdnjs.cloudflare.com/ajax/libs/lodash.js/3.2.0/lodash.js");

promise.then(
  script => alert(`${script.src} is loaded!`),
  error => alert(`Error: ${error.message}`)
);

promise.then(script => alert('One more handler to do something else!'));





Chaining promises:
----------------------
loadScript("/article/promise-chaining/one.js")
  .then(function(script) {
			return loadScript("/article/promise-chaining/two.js");
  })
  .then(function(script) {
		return loadScript("/article/promise-chaining/three.js");
  })
  .then(function(script) {
    one();
    two();
    three();
  });

  
or:

loadScript("/article/promise-chaining/one.js").then(function(script1) {
  loadScript("/article/promise-chaining/two.js").then(function(script2) {
    loadScript("/article/promise-chaining/three.js").then(function(script3) {
		  one();
		  two();
		  three();
    });
  });
});  



Promise API
++++++++++++++++++++++++++

i) let promise = new Promise(resolve => resolve(value));

ii) let promise = new Promise((resolve, reject) => reject(error));

iii) Promise.all:

The method to run many promises in parallel and wait till all of them are ready.
The syntax is:
let promise = Promise.all(iterable);

Promise.all([
  new Promise((resolve, reject) => setTimeout(() => resolve(1), 3000)), // 1
  new Promise((resolve, reject) => setTimeout(() => resolve(2), 2000)), // 2
  new Promise((resolve, reject) => setTimeout(() => resolve(3), 1000))  // 3
]).then(alert); // 1,2,3 when promises are ready: each promise contributes an array member


iv)

For instance:

Promise.all([
  new Promise((resolve, reject) => setTimeout(() => resolve(1), 1000)),
  new Promise((resolve, reject) => setTimeout(() => reject(new Error("Whoops!")), 2000)),
  new Promise((resolve, reject) => setTimeout(() => resolve(3), 3000))
]).catch(alert); // Error: Whoops!
Here the second promise rejects in two seconds. That leads to immediate rejection of Promise.all, so .catch executes: the rejection error becomes the outcome of the whole Promise.all.


v)
Promise.race

Similar to Promise.all takes an iterable of promises, but instead of waiting for all of them to finish – waits for the first result (or error), and goes on with it.

The syntax is:

let promise = Promise.race(iterable);
For instance, here the result will be 1:

 Promise.race([
  new Promise((resolve, reject) => setTimeout(() => resolve(1), 1000)),
  new Promise((resolve, reject) => setTimeout(() => reject(new Error("Whoops!")), 2000)),
  new Promise((resolve, reject) => setTimeout(() => resolve(3), 3000))
]).then(alert); // 1
  



  
Categorizing ES6 Features
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

1) JavaScript “let” Keyword
-----------------------------------------------

“let” keyword was introduced in ES6. It lets you define block scope(bracket scope) variables in JavaScript. Initially JavaScript only supported function scope and global scope variables.

Here is an example code

if(true)
{
    let x = 12;
    alert(x); //alert's 12
}

alert(x); //x is undefined here


2)JavaScript “const” Keyword
-------------------------------------------------
“const” keyword was introduced in ES6. It lets you define read only variables using JavaScript. Variables created using “const” are block scoped(or bracket scoped). Redeclaring a “const” variable in the same scope throws an error.

const x = 12;

//an constant 'x' is already available in this scope therefore the below line throws an error when you are try to create a new x variable.
const x = 13;

if(true)
{
    //an constant 'x' is available in this scope but not defined in this scope therefore the below line will not throw error instead define a new "x" inside this scope.
    const x = 13;
    
    //here 'y' is available inside this scope not outside this scope
    const y = 11;
}

//here creating a new 'y' will not throw an error because no other 'y' is available in this scope(i.e., global scope)
const y = 12;



3) JavaScript Function Return Multiple Values
------------------------------------------------------
function function_name()
{
    return [1, 6, 7, 4, 8, 0]; //here we are storing variables in an array and returning the array
}

var q, w, e, r, t, y;

//Here we are using ES6's array destructuring feature to assign the returned values to variables.
//Here we are ignoring 2 and 4 array indexes
[q, w, , r, , y] = function_name();

alert(y);//y is 0




var o = {p: 42, q: true};
var {p, q} = o;

console.log(p); // 42
console.log(q); // true






function function_name()
{
    var a=1;var b=2;
    return {a,b} 
}

let {a, b} = function_name()





4)Default Function Arguments Values in JavaScript
--------------------------------------------------------------
ES6 provides a new syntax that can be used to define default values to function parameters:

function myFunction(x = 1, y = 2, z = 3)
{
     console.log(x, y, z); // Output "6 7 3"
}
myFunction(6,7);


function myFunction(x = 1, y = 2, z = 3)
{
 console.log(x, y, z); // Output "1 7 9"
}
myFunction(undefined,7,9);
   
   
function myFunction(x = 1, y = 2, z = 3 + 5)
{
 console.log(x, y, z); // Output "6 7 8"
}
 myFunction(6,7);
 
 
 
 
5)JavaScript “…” Operator(Spread in operator)
-----------------------------------------------------------
ES6 introduced “…” operator which is also called as spread operator. When “…” operator is applied on an array it expands the array into multiple variables in syntax wise. And when its applied to an function argument it makes the function argument behave like array of arguments.



//args variable is an array holding the passed function arguments
function function_one(...args)
{   
    console.log(args);
    console.log(args.length);
}

function_one(1, 4);
function_one(1, 4, 7);
function_one(1, 4, 7, 0);


function function_two(a, b, ...args)
{
    console.log(args);
    console.log(args.length);
}

//"args" holds only 7 and 9
function_two(1, 5, 7, 9);




function function_name(a, b)
{
    console.log(a+b);
}

var array = [1, 4];

function_name(...array); //is equal to function_name(1, 4)






6) Multiline string In JavaScript
---------------------------------------------
Using the “\” character. Actually “\” character allows us to spread the string over multiple lines.So we can say “\” allows us to create line concatenated string.

var string = "This is first line \n\
This is second line \n\
This is third line \n\
";

console.log(string);


var string = "This is first line\
This is second line\
This is third line\
";
console.log(string);


7)JavaScript “class” Keyword
------------------------------------------------------
ECMAScript 6 introduced “class” keyword to define classes in JavaScript. Earlier to ES6, we had to use constructor function.
Here is an example code on how to define classes and then how to create objects of those class types i.e., instances of classes.

class Student
{
    constructor(name, age)
    {
        this.name = name;

        this._age = age;
    }

    //member function
    getName()
    {
        return this.name;
    }

    setName(name)
    {
        this.name = name;
    }

    //getters and setters make a function accessible like a variable. They are used as wrappers around other variables.
    set age(value)
    {
        this._age = value;
    }

    get age()
    {
        return this._age;
    }
}

//class person inherits student class
class Person extends Student
{
    constructor(name, age, citizen)
    {
        this.citizen = citizen;
        super(name, age);
    }

    getCitizen()
    {
        return this.citizen;
    }

    getName()
    {
        return super.getName();
    }
}

//instance of student class
var stud = new Student("Narayan", 21);

//instance of person class
var p = new Person("Narayan Prusty", 21, "India");

stud.age = 12; //executes setter
console.log(stud.age); //executes getter



8)JavaScript Arrow “=>” Function
------------------------------------------------------
ECMAScript 6 provides a new way to create functions which just contain one line of statement. This new type of function is called lambda or arrow function.

var sum = (x, y) => x + y;
console.log(sum(2, 900)); //902

Here (x, y) => x + y returns a regular  function object. Here the function body of the returned function object’s body would be function(x, y){return x+ y;}


You can also write multiple statements in an arrow function but arrow functions are mostly used in replacement of single statement functions. Here is code example of multiple statements in an arrow function

var sum = (x, y) => {
    x = x + 10;
    y = y + 10;
    return x + y;
}
console.log(sum(10, 10)); //40








9)JavaScript “yield” Keyword and “function*()” Syntax
--------------------------------------------------------------------
ECMAScript 6 specification introduced a new JavaScript feature called as JavaScript Generators. JavaScript’s yield keyword and function*() syntax together make JS Generators.
JavaScript generators provide a new way for functions to return a collection.


The yield keyword is used to pause and resume a generator function

function* collection_name()
{
    yield 1;
    yield 3;
    yield 5;
    yield 7;
}

for(var iii  of collection_name())
{
    console.log(iii);
}





function* foo() {
  var index = 0;
  while (index <= 2)
    yield index++;
}

var iterator = foo();
console.log(iterator.next()); // { value: 0, done: false }
console.log(iterator.next()); // { value: 1, done: false }
console.log(iterator.next()); // { value: 2, done: false }
console.log(iterator.next()); // { value: undefined, done: true }










10)JavaScript “Set” Object(Basically 1 D)
---------------------------------------------------------
JavaScript “Set” object is a collection of unique keys. Arrays can store duplicate values but Sets don’t store duplicate keys, this is what makes it different from arrays.

//create a set
var set = new Set();

//add three keys to the set
set.add({x: 12});
set.add(44);
set.add("text");

//check if a provided key is present
console.log(set.has("text"));

//delete a key
set.delete(44);

//loop through the keys in an set
for(var i of set.values())
{
    console.log(i);
}

//create a set from array values
var set_1 = new Set([1, 2, 3, 4, 5]); 

//size of set
console.log(set_1.size); //5

//create a clone of another set
var set_2 = new Set(set.values());








11)JavaScript “Map” Object(Key values)
--------------------------------------------------

JavaScript “Map” object is a collection of unique keys and corresponding values. Keys and Values can be object references or primitive types.

i)
	//create a map
	var map = new Map();

	//add three keys & values to the map
	map.set({x: 12}, 12);

	//same key is overwritten
	map.set(44, 13);
	map.set(44, 12);

	//check if a provided key is present
	console.log(map.has(44)); //true

	//retrieve key
	console.log(map.get(44)); //12

	//delete a key
	map.delete(44);

	//loop through the keys in an map
	for(var i of map)
	{
		console.log(i);
	}

	//delete all keys
	map.clear();

	//create a map from arrays
	var map_1 = new Map([[1, 2], [4, 5]]); 

	//size of map
	console.log(map_1.size);





ii)
	Developers usually just use regular JavaScript objects when they want maps.

	var obj = {};
	obj.name= "Anand Deep Singh";
	console.log(obj.name); //logs "Anand Deep Singh"


	similarly in ES6, we can use regular object.

	var map = new Map();
	map.set("name","Anand Deep Singh");
	console.log(map.get("name")); //logs "Anand Deep Singh"

	But noticeable thing is a Map isn’t created with the literal object syntax, and that one uses set and get methods to store and access data.

	It has has method to check weather key is existing in object or not, delete method to delete object and clear method to clear entire object.


	Set is a unique list of values. It’s simply a unique list.

	var set = new Set(["a", "a","e", "b", "c", "b", "b", "b", "d"]);
	console.log(set); //logs Set {"a", "e", "b", "c", "d"}
	Sets can’t be accessed like an array it has its own methods to acces its value.
	





	
	
12) Diffrence between set and weak set
------------------------------------------------------------------

The main difference is that references to objects in Set are strong while references to objects in WeakSet are weak. This means that an object in WeakSet can be garbage collected if there is no other reference to it.

Other differences (or rather side-effects) are:

Sets can store any value. WeakSets are collections of objects only.
WeakSet does not have size property.
WeakSet does not have clear, keys, values, entries, for methods.
WeakSet is not iterable



var set = new Set([1,2,3,4]);

//cannot be created from array or another set
var weakset = new WeakSet();
weakset.add({a: 1}); //object reference must





“WeakSet” doesn’t provide any methods or functions to work with the whole set of keys. For example: size, looping etc.
var set = new Set([1,2,3,4]);

//cannot be created from array
var weakset = new WeakSet();
weakset.add({a: 1}); //object reference must

console.log(set.size);//4
console.log(weakset.size);//undefined

for(var i of set)
{
    console.log(i); //1,2.3.4
}

//doesn't execute throws error
for(var i of weakset)
{
    console.log(i);
}

set.clear();//This works
weakset.clear(); //this dont works.