1) Chnage Detection in angular:
++++++++++++++++++++++++++++++++++++++++++++
Angular application is a tree of components. However, under the hood angular uses a low-level abstraction called view. There is a direct relationship between a view and a component?�?one view is associated with one component and vice verse.

All operations like property checks and DOM updates are performed on views, hence it�s more technically correct to state that angular is a tree of views.


View state:
Each view has a state, which plays very important role because based on its value Angular decides whether to run change detection for the view and all its children or skip it.

FirstCheck
ChecksEnabled
Errored
Destroyed

Change detection is skipped for the view and its child views if ChecksEnabled is false or view is in the Errored or Destroyed state.

This viewRef is what you can inject into a component constructor using ChangeDetectorRef.

export class AppComponent {
    constructor(cd: ChangeDetectorRef) { ... }
}


change detection is performed recursively for each component.
It means that a child component becomes parent component on the next call as a recursive tree.


ViewState.firstCheck to true if a view is checked for the first time and to false if it was already checked before.


Example how the Change detection works:
-------------------------------------------

			APP
  AComp				BComp
AA  AC		      BB	Bc


each component is associated with a component view. Each view is initialized with the ViewState.ChecksEnabled which means when angular runs change detection every component in the tree will be checked.

Suppose we want to disable change detection for the AComponent and its children. That�s easy to do?�?we just need to set ViewState.ChecksEnabled to false. Angular provides for us a bunch of public methods available on the view. Every component can get a hold of its associated view through ChangeDetectorRef.


For this class Angular docs define the following public interface:

class ChangeDetectorRef {
  markForCheck() : void
  detach() : void
  reattach() : void
  
  detectChanges() : void
  checkNoChanges() : void
}


i) detach:
----------------
The first method that allows us manipulating the state is detach which simply disables checks for the current view:

export class AComponent {
  constructor(public cd: ChangeDetectorRef) {
    this.cd.detach();
  }
  
  
ii) reattach:
----------------
This method simply enables checks for the current view:
Since reattach simply sets ViewState.ChecksEnabled for current component



iii) markForCheck:
-----------------------
The reattach method enables checks for the current component only.
markForCheck simply goes upwards from the current component to the root component and updates their view state to ChecksEnabled. 


iv) detectChanges:
------------------------------
This method is used to run change detection regardless of its state for the tree of components starting with the component that you trigger detectChanges()
  
  
v) checkNoChanges:
  ---------------------
  This last method available on the change detector ensures that there will be no changes done on the current run. Basically, it throws an exception if it finds a changed or determines that DOM should be updated.

 
 
Example of the change detection:
---------------------------------------------- 
Our AppComponent will have three properties: the slogan of the app, the title of the movie and the lead actor. The last two properties will be passed to the MovieComponent element referenced in the template.

app/app.component.ts:
----------------------------
import {Component} from '@angular/core';
import {MovieComponent} from './movie.component';
import {Actor} from './actor.model';

@Component({
  selector: 'app-root',
  template: `
    <h1>MovieApp</h1>
    <p>{{ slogan }}</p>
    <button type="button" (click)="changeActorProperties()">
      Change Actor Properties
    </button>
    <button type="button" (click)="changeActorObject()">
      Change Actor Object
    </button>
    <app-movie [title]="title" [actor]="actor"></app-movie>`
})
export class AppComponent {
  slogan = 'Just movie information';
  title = 'Terminator 1';
  actor = new Actor('Arnold', 'Schwarzenegger');

  changeActorProperties() {
    this.actor.firstName = 'Nicholas';
    this.actor.lastName = 'Cage';
  }

  changeActorObject() {
    this.actor = new Actor('Bruce', 'Willis');
  }
}


ii)app/actor.model.ts
---------------------------
export class Actor {
  constructor(
    public firstName: string,
    public lastName: string) {}
}


iii) Finally, the MovieComponent shows the information provided by the AppComponent in its template.
app/movie.component.ts
import { Component, Input } from '@angular/core';
import { Actor } from './actor.model';

@Component({
  selector: 'app-movie',
  template: `
    <div>
      <h3>{{ title }}</h3>
      <p>
        <label>Actor:</label>
        <span>{{actor.firstName}} {{actor.lastName}}</span>
      </p>
    </div>`
})
export class MovieComponent {
  @Input() title: string;
  @Input() actor: Actor;
}



At runtime, Angular will create special classes that are called change detectors, one for every component that we have defined. In this case, Angular will create two classes: AppComponent and AppComponent_ChangeDetector.

The goal of the change detectors is to know which model properties used in the template of a component have changed since the last time the change detection process ran.


iv) 
	The code snippet below is a conceptual model of how the AppComponent_ChangeDetector class might look.
class AppComponent_ChangeDetector {

  constructor(
    public previousSlogan: string,
    public previousTitle: string,
    public previousActor: Actor,
    public movieComponent: MovieComponent
  ) {}

  detectChanges(slogan: string, title: string, actor: Actor) {
    if (slogan !== this.previousSlogan) {
      this.previousSlogan = slogan;
      this.movieComponent.slogan = slogan;
    }
    if (title !== this.previousTitle) {
      this.previousTitle = title;
      this.movieComponent.title = title;
    }
    if (actor !== this.previousActor) {
      this.previousActor = actor;
      this.movieComponent.actor = actor;
    }
  }
}




Change Detection Strategy: Default
------------------------------------
By default, Angular defines a certain change detection strategy for every component in our application. To make this definition explicit, we can use the property changeDetection of the @Component decorator.
app/movie.component.ts
import { ChangeDetectionStrategy } from '@angular/core';

@Component({
  // ...
  changeDetection: ChangeDetectionStrategy.Default
})
export class MovieComponent {
  // ...
}

Let's see what happens when a user clicks the button "Change Actor Properties" when using the Default strategy.

changes is done in two phases: the application phase and the change detection phase.

i) Phase 1 (Application):
In the first phase, the application (our code) is responsible for updating the models in response to some event. In this scenario, the properties actor.firstName and actor.lastName are updated.

ii) Phase 2 (Change Detection):
Now that our models are updated, Angular must update the templates using change detection.

Change detection always starts at the root component, in this case the AppComponent, and checks if any of the model properties bound to its template have changed, comparing the old value of each property (before the event was triggered) to the new one (after the models were updated). 

The AppComponent template has a reference to three properties, slogan, title and actor, so the comparison made by its corresponding change detector will look like:
Is slogan !== previousSlogan? No, it's the same.
Is title !== previousTitle? No, it's the same.
Is actor !== previousActor? No, it's the same.


Notice that even if we change the properties of the actor object, we are always working with the same instance. Because we are doing a shallow comparison, the result of asking if actor !== previousActor will always be false even when its internal property values have indeed changed. Even though the change detector was unable to find any change, the default strategy for the change detection is to traverse all the components of the tree even if they do not seem to have been modified.


Next, change detection moves down in the component hierarchy and check the properties bound to the MovieComponent's template doing a similar comparison:
Is title !== previousTitle? No, it's the same.
Is actorFirstName !== previousActorFirstName? Yes, it has changed.
Is actorLastName !== previousActorLastName? Yes, it has changed.
Finally, Angular has detected that some of the properties bound to the template have changed so it will update the DOM to get the view in sync with the model.


Performance Impact:
------------------------
Traversing all the tree components to check for changes could be costly. Imagine that instead of just having one reference to <app-movie> inside our AppComponent's template, we have multiple references?
<movie *ngFor="let movie of movies" [title]="movie.title" [actor]="movie.actor"></movie>`
If our movie list grows too big, the performance of our system will start degrading.



What if we can find a way to indicate to the change detection that our MovieComponent depends only on its inputs and that these inputs are immutable? 

 In short, we are trying to guarantee that when we change any of the properties of the actor object, we end up with a different Actor instance so the comparison actor !== previousActor will always return true.
 if we did not change any property, we are not going to create a new instance, so the same comparison is going to return false.


 
 Change Detection Strategy: OnPush:
 --------------------------------------
app/movie.component.ts
@Component({
  // ...
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MovieComponent {
  // ...
}


This will inform Angular that our component only depends on its inputs and that any object that is passed to it should be considered immutable.



When the change detection analyzes the properties bound to the AppComponent's template, it will see the same picture as before:
Is slogan !== previousSlogan No, it's the same.
Is title !== previousTitle? No, it's the same.
Is actor !== previousActor? No, it's the same

Because change detection now knows that the actor object hasent changed  it will not go ahead and continue checking the template for MovieComponent.

Let's rerun the app but this time we will click the "Change Actor Object" button. This time, we are creating a new instance of the Actor class and assigning it to the this.actor object. When change detection analyzes the properties bound to the AppComponent's template it will find:
Is slogan !== previousSlogan No, it's the same.
Is title !== previousTitle? No, it's the same.
Is actor !== previousActor? Yes, it has changed.
Because change detection now knows that the actor object changed (it's a new instance) it will go ahead and continue checking the template for MovieComponent to update its view. At the end, our templates and models are in sync.



x) OnChanges: detect whenever @Input changes:
---------------------------------------------------
i)
import { OnChanges } from '@angular/core';

@Component({
	selector: 'child',
	template: `
		<h2>Child component</h2>
		{{ person }}
	`
})
class ChildComponent implements OnChanges {
	@Input() person: string;

	ngOnChanges(changes: {[ propName: string]: SimpleChange}) {
		console.log('Change detected:', changes[person].currentValue);
	}

}



ii) 
@Component({
  selector: 'my-app',
  providers: [],
  template: `
    <div>
      <h1>Parent</h1>
      <button (click)="changePerson()">change name</button>
      <child [person]="person"></child>
    </div>
  `
})
class App {
  person: string;
  
  constructor() {
    this.person = 'Juri';
  }
  
  changePerson() {
    this.person = 'Thomas';
  }
}




In our changePerson() function, we now directly mutate the property of our person object which we pass on to our child component. All of a sudden, while the data binding still works, ngOnChanges is not being invoked any more.

Instead, if we make our person object immutable, it works just fine:

changePerson() {
	this.person = {
		name: 'Thomas'
	};
}


xx) But what if I always want to get notified?

So, cool, using immutable data structures definitely has some performance benefits on Angular anyways. 
I don�t care about immutable datastructures right now, how can I get to know about changes in my objects? DoCheck can be of help here.

ngOnChanges() is called when a value bound to an input has changed.

ngDoCheck() ngDoCheck() is invoked whenever change detection is run.

That allows us to implement some logic there, like remembering the old values and comparing them against new ones. There�s a smarter way, though, by using the KeyValueDiffers class.

import { DoCheck, KeyValueDiffers } from '@angular/core';

@Component({...})
class ChildComponent implements DoCheck {
	@Input() person: any;
	differ: any;

	constructor(private differs: KeyValueDiffers) {
		this.differ = differs.find({}).create(null);
	}
	...
	ngDoCheck() {
		var changes = this.differ.diff(this.person);

		if(changes) {
			console.log('changes detected');
			changes.forEachChangedItem(r => console.log('changed ', r.currentValue));
			changes.forEachAddedItem(r => console.log('added ' + r.currentValue));
			changes.forEachRemovedItem(r => console.log('removed ' + r.currentValue));
		} else {
			console.log('nothing changed');
		}
	}
}


or

//our root app component
import {NgModule} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'
import {Component, Input, DoCheck, KeyValueDiffers,ChangeDetectorRef,ChangeDetectionStrategy } from '@angular/core'

@Component({
  selector: 'child',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template:`
    <h2>Child component</h2>
    {{ person.name }}
  `
})
class ChildComponent implements DoCheck {
  @Input() person: any;
  differ: any;
  
  constructor(private cd: ChangeDetectorRef){ 
    
  }
  
  ngOnChanges(changes: {[propName: string]: SimpleChange}) {
    console.log('onChanges - person = ', changes['person'].currentValue);
  }
  
  ngDoCheck() {
    this.cd.detectChanges()
  }
  
}

@Component({
  selector: 'my-app',
  providers: [],
  template: `
    <div>
      <h1>Parent</h1>
      <button (click)="changePerson()">change name</button>
      <child [person]="person"></child>
    </div>
  `
})
class App {
  private person: any;
  
  constructor() {
    this.person = {
      name: 'Juri'
    }
  }
  
  changePerson() {
    // ngOnChanges doesn't fire on child components when
    // changing mutable objects...only when the obj ref changes..
    
   this.person.name = 'Thomas';
    this.person.age = 26;
    //this.person = { name: 'Thomas' };
  }
}
@NgModule({
  imports: [ BrowserModule ],
  declarations: [ App, ChildComponent ],
  bootstrap: [ App ]
})
export class AppModule {}




